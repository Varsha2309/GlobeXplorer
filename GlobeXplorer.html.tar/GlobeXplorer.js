fetch('GlobeXplorer_api.json')
    .then(response => response.json())
    .then(data => console.log(data))
    .catch(error => console.error('Error fetching data:', error));
    document.getElementById('search-button').addEventListener('click', function() {
        const query = document.getElementById('search-bar').value.toLowerCase();
        // Search logic here
        // Filter recommendations based on the query
        const filteredResults = recommendations.filter(item => {
            return item.name.toLowerCase().includes(query) || // Check the name
               item.type.toLowerCase().includes(query); // Check the type (if available)
    });

    // Call a function to display the results
    displayResults(filteredResults);
});
function displayResults(results) {
    const resultsContainer = document.getElementById('results-container'); // Assume you have this element in your HTML
    resultsContainer.innerHTML = ''; // Clear previous results

    if (results.length > 0) {
        results.forEach(result => {
            const resultElement = document.createElement('div');
            resultElement.classList.add('result-item'); // Add styling class if needed
            
            // Populate with content
            resultElement.innerHTML = `
                <h3>${result.name}</h3>
                <img src="${result.imageUrl}" alt="${result.name}">
                <p>${result.description}</p>
            `;
            resultsContainer.appendChild(resultElement); // Add to the container
        });
    } else {
        resultsContainer.innerHTML = '<p>No results found.</p>'; // No results message
    }
}
document.getElementById('reset-button').addEventListener('click', function() {
    document.getElementById('search-bar').value = '';
    // Clear displayed results here
});
const options = { timeZone: 'America/New_York', hour12: true, hour: 'numeric', minute: 'numeric', second: 'numeric' };
const newYorkTime = new Date().toLocaleTimeString('en-US', options);
console.log("Current time in New York:", newYorkTime);
